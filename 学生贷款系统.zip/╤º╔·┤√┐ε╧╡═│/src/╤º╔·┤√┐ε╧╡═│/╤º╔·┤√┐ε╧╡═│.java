
package 学生贷款系统;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static 学生贷款系统.学生贷款系统.con;

public class 学生贷款系统 {

public static Connection con; //连接只需要建立一次 
    public static void main(String[] args) {
        //连接数据库，若连接成功则显示登录界面 ?characterEncoding=utf8协议不知道写到哪
        try
        {
            DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
            
            con=DriverManager.getConnection("jdbc:odbc:Loan","sa","12345678");
            
            System.out.println("连接数据库成功");
            new Loading().setVisible(true);
        } catch (SQLException ex) {
            System.out.println("查询失败");
        Logger.getLogger(学生贷款系统.class.getName()).log(Level.SEVERE, null, ex);
    }

    }
    public static String chinaToUnicode(String str) {
		String result = "";
		for (int i = 0; i < str.length(); i++) {
			int chr1 = (char) str.charAt(i);
			if (chr1 >= 19968 && chr1 <= 171941) {// 汉字范围 \u4e00-\u9fa5 (中文)
				result += "\\u" + Integer.toHexString(chr1);
			} else {
				result += str.charAt(i);
			}
		}
		return result;
    }
}
